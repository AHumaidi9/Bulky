﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace BulkyWebRazor_Temp.Models
{
    namespace BulkyWeb.Models
    {
        public class Category
        {
            [Key]
            public int Id { get; set; }
            [Required]
            [DisplayName("Category Name")]
            [MaxLength(30)]
            public string Name { get; set; }
            [DisplayName("Display Order")]
            [Range(1, 500, ErrorMessage = "Display order must be between 1- 500")]
            public int DisplayOrder { get; set; }
        }
    }
}
